Docent tour pack: 3 personalized postcards (SVG + PNG proof), operator receipt.
Verify with: tar xzf tour-pack.tar.gz && sha256sum cards/*.svg (compare operator-receipt.json)
