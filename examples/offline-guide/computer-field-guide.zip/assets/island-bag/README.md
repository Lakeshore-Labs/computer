# Island reading bag

Open index.html to compare the cards, or download either CAR. The receiving store reuses the original EPUB.

[Full replay, source, and verification](https://github.com/Lakeshore-Labs/computer/tree/33971c0/examples/island-mailbag)
