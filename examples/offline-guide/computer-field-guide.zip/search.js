const box = document.querySelector('#query')
const categories = [...document.querySelectorAll('.category')]
function filter() {
  const words = box.value.trim().toLowerCase().split(/\s+/).filter(Boolean)
  let count = 0
  for (const [i, group] of categories.entries()) {
    let matches = 0
    for (const item of group.querySelectorAll('.item')) {
      item.hidden = !words.every(word => item.dataset.search.includes(word))
      if (!item.hidden) matches++
    }
    group.hidden = matches === 0
    group.open = words.length > 0 || i === 0
    count += matches
  }
  document.querySelector('#matches').textContent = words.length ? count + (count === 1 ? ' matching exhibit' : ' matching exhibits') : ''
}
box.addEventListener('input', filter)
